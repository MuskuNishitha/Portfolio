import Resume from "@/mainPages/portfolioPages/Resume";
import React from "react";

const page = () => {
  return (
    <div>
      <Resume />
    </div>
  );
};

export default page;
