// components/Footer.jsx
import Image from "next/image";
import Link from "next/link";
import { FaGithub, FaLinkedin, FaPhone } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { socialLinksArray } from "./SocialMediaLinks";

const navigationItems = [
  { name: "Services", href: "/services" },
  { name: "Portfolio", href: "/Portfolio" },
  { name: "Resume", href: "/Resume" },
  { name: "Blog", href: "/Blog" },
  { name: "Contact", href: "/Contact" },
];

// Map icon strings to actual components
const iconMap = {
  FaGithub: FaGithub,
  FaLinkedin: FaLinkedin,
  FaPhone: FaPhone,
  MdEmail: MdEmail,
};

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-bg-3 border-t border-border py-12 md:py-16">
      <div className="container-custom">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <Link 
            href="/" 
            className="inline-block transition-opacity hover:opacity-80"
            aria-label="Go to homepage"
          >
            <div className="relative w-[140px] h-[80px]">
              <Image
                src="/assets/white_bg.png"
                alt="Company Logo"
                fill
                sizes="140px"
                className="object-contain"
                priority
              />
            </div>
          </Link>
        </div>

        {/* Navigation Links */}
        <nav className="flex justify-center mb-8" aria-label="Footer navigation">
          <ul className="flex flex-wrap items-center justify-center gap-6 md:gap-8">
            {navigationItems.map((item) => (
              <li key={item.name}>
                <Link
                  href={item.href}
                  className="text-sm text-text-muted font-medium hover:text-primary-3 transition-colors duration-200"
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Social Links */}
        <div className="flex justify-center gap-4 mb-8">
          {socialLinksArray.map((social) => {
            const IconComponent = iconMap[social.icon];
            return (
              <a
                key={social.name}
                href={social.link}
                target={social.link.startsWith('http') ? "_blank" : undefined}
                rel={social.link.startsWith('http') ? "noopener noreferrer" : undefined}
                className="w-10 h-10 flex items-center justify-center rounded-full bg-bg-2 text-text-muted hover:bg-primary-3 hover:text-white transition-all duration-200"
                aria-label={`Visit our ${social.name} page`}
              >
                <IconComponent className="text-lg" aria-hidden="true" />
              </a>
            );
          })}
        </div>

        {/* Copyright */}
        <div className="text-center text-sm text-text-muted">
          <p>
            © {currentYear} All rights reserved by{" "}
            <span className="text-primary-3 hover:text-primary transition-colors duration-200 font-medium">
              Musku Nishitha Reddy
            </span>
          </p>
        </div>
      </div>
    </footer>
  );
}