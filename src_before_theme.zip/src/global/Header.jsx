"use client";

import { useState, useEffect } from "react";
import { useTheme } from "@/components/ThemeProvider";
import Link from "next/link";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { 
  FiMail, 
  FiSun, 
  FiMoon, 
  FiMenu, 
  FiX, 
  FiArrowRight,
  FiHome,
  FiUser,
  FiSettings,
  FiFolder,
  FiFileText,
  FiBookOpen,
  FiMail as FiMailIcon,
  FiGithub,
  FiLinkedin,
  FiTwitter
} from "react-icons/fi";
import { 
  HiOutlineBriefcase, 
  HiOutlineDocumentText 
} from "react-icons/hi";
import { 
  MdOutlineDashboardCustomize 
} from "react-icons/md";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeItem, setActiveItem] = useState("/");
  const { isDarkMode, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    setActiveItem(window.location.pathname);

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [mobileMenuOpen]);

  const navItems = [
    { name: "Home", path: "/", icon: FiHome },
    { name: "About", path: "/about", icon: FiUser },
    { name: "Services", path: "/services", icon: FiSettings },
    { name: "Portfolio", path: "/Portfolio", icon: FiFolder },
    { name: "Resume", path: "/Resume", icon: FiFileText },
    { name: "Blog", path: "/Blog", icon: FiBookOpen },
    { name: "Contact", path: "/Contact", icon: FiMailIcon },
  ];

  const socialLinks = [
    { icon: FiGithub, href: "https://github.com", label: "GitHub" },
    { icon: FiLinkedin, href: "https://linkedin.com", label: "LinkedIn" },
    { icon: FiTwitter, href: "https://twitter.com", label: "Twitter" },
  ];

  const handleNavClick = (path) => {
    setActiveItem(path);
    setMobileMenuOpen(false);
  };

  const headerVariants = {
    initial: { y: -100, opacity: 0 },
    animate: { y: 0, opacity: 1, transition: { duration: 0.5, ease: "easeOut" } },
  };

  const mobileMenuVariants = {
    closed: { opacity: 0, x: "100%", transition: { duration: 0.3, ease: "easeInOut" } },
    open: { opacity: 1, x: 0, transition: { duration: 0.3, ease: "easeInOut" } },
  };

  const navItemVariants = {
    closed: { opacity: 0, x: 50 },
    open: (i) => ({
      opacity: 1,
      x: 0,
      transition: { delay: i * 0.05, duration: 0.3, ease: "easeOut" },
    }),
  };

  return (
    <>
      <motion.header
        variants={headerVariants}
        initial="initial"
        animate="animate"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl shadow-lg dark:shadow-2xl border-b border-gray-200/50 dark:border-gray-800/50"
            : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 lg:h-24">
            {/* Logo */}
            <Link 
              href="/" 
              className="group relative flex-shrink-0" 
              onClick={() => handleNavClick("/")}
            >
              <motion.div 
                className="relative w-[100px] sm:w-[120px] lg:w-[140px] h-[50px] sm:h-[60px] lg:h-[70px] transition-all duration-300 group-hover:scale-105"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <Image
                  src="/assets/white_bg.png"
                  alt="Logo"
                  fill
                  className="object-contain"
                  priority
                />
              </motion.div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    href={item.path}
                    onClick={() => handleNavClick(item.path)}
                    className={`relative px-3 xl:px-4 py-2 text-sm xl:text-base font-medium transition-all duration-300 group flex items-center gap-2 ${
                      activeItem === item.path
                        ? "text-primary"
                        : "text-gray-700 dark:text-gray-300 hover:text-primary"
                    }`}
                  >
                    <Icon className="w-4 h-4 xl:w-5 xl:h-5" />
                    <span className="relative z-10">{item.name}</span>
                    
                    {activeItem === item.path && (
                      <motion.span
                        layoutId="activeNav"
                        className="absolute inset-0 bg-primary/10 dark:bg-primary/20 rounded-lg"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                    
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-1/2" />
                  </Link>
                );
              })}
            </nav>

            {/* Tablet Navigation */}
            <nav className="hidden md:flex lg:hidden items-center gap-1">
              {navItems.slice(0, 4).map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    href={item.path}
                    onClick={() => handleNavClick(item.path)}
                    className={`relative px-2.5 py-2 text-xs font-medium transition-all duration-300 flex items-center gap-1.5 ${
                      activeItem === item.path
                        ? "text-primary"
                        : "text-gray-700 dark:text-gray-300 hover:text-primary"
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{item.name}</span>
                    {activeItem === item.path && (
                      <motion.span
                        layoutId="activeNavTablet"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                  </Link>
                );
              })}
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="px-3 py-2 text-xs font-medium text-gray-700 dark:text-gray-300 hover:text-primary transition-all hover:scale-105 flex items-center gap-1"
              >
                <MdOutlineDashboardCustomize className="w-4 h-4" />
                <span>More</span>
              </button>
            </nav>

            {/* Right Section */}
            <div className="hidden md:flex items-center gap-2 lg:gap-3 xl:gap-4">
              {/* Email */}
              <motion.a
                href="mailto:mnishithareddy8765@gmail.com"
                className="hidden xl:flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 hover:text-primary transition-colors px-3 py-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <FiMail className="w-4 h-4" />
                <span>mnishithareddy8765@gmail.com</span>
              </motion.a>

              {/* Social Links */}
              <div className="hidden lg:flex items-center gap-1">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-gray-600 dark:text-gray-400 hover:text-primary transition-colors rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <social.icon className="w-4 h-4 lg:w-5 lg:h-5" />
                  </motion.a>
                ))}
              </div>

              {/* Theme Toggle */}
              <motion.button
                onClick={toggleTheme}
                className="relative w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center transition-all hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
                whileHover={{ scale: 1.1, rotate: isDarkMode ? -180 : 180 }}
                whileTap={{ scale: 0.9 }}
                aria-label="Toggle theme"
              >
                <motion.div
                  initial={false}
                  animate={{ rotate: isDarkMode ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="relative w-5 h-5"
                >
                  {!isDarkMode ? (
                    <FiSun className="w-full h-full text-yellow-500" />
                  ) : (
                    <FiMoon className="w-full h-full text-primary" />
                  )}
                </motion.div>
              </motion.button>

              {/* Hire Me Button */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link
                  href="/Contact"
                  className="group relative inline-flex items-center gap-2 bg-gradient-to-r from-primary to-primary/80 text-white font-semibold rounded-full py-2.5 px-5 lg:py-3 lg:px-6 overflow-hidden transition-all duration-300 hover:shadow-xl text-sm lg:text-base"
                >
                  <span className="relative z-10">Hire Me!</span>
                  <motion.span
                    className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary"
                    initial={{ x: "100%" }}
                    whileHover={{ x: 0 }}
                    transition={{ duration: 0.3 }}
                  />
                  <span className="relative z-10 flex-shrink-0 w-5 h-5 bg-white rounded-full grid place-items-center">
                    <FiArrowRight className="w-2.5 h-2.5 text-primary" />
                  </span>
                </Link>
              </motion.div>
            </div>

            {/* Mobile Menu Button */}
            <motion.button
              className="md:hidden flex flex-col gap-1.5 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              whileTap={{ scale: 0.95 }}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <FiX className="w-6 h-6 text-gray-800 dark:text-gray-200" />
              ) : (
                <FiMenu className="w-6 h-6 text-gray-800 dark:text-gray-200" />
              )}
            </motion.button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            
            {/* Menu Panel */}
            <motion.div
              variants={mobileMenuVariants}
              initial="closed"
              animate="open"
              exit="closed"
              className="fixed right-0 top-0 bottom-0 w-full max-w-sm bg-white dark:bg-gray-900 shadow-2xl z-50 md:hidden"
            >
              <div className="flex flex-col h-full">
                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-800">
                  <div className="relative w-24 h-12">
                    <Image
                      src="/assets/white_bg.png"
                      alt="Logo"
                      fill
                      className="object-contain"
                    />
                  </div>
                  <motion.button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    whileTap={{ scale: 0.9 }}
                  >
                    <FiX className="w-6 h-6 text-gray-800 dark:text-gray-200" />
                  </motion.button>
                </div>

                {/* Navigation Items */}
                <nav className="flex-1 overflow-y-auto py-6 px-6">
                  {navItems.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <motion.div
                        key={item.name}
                        custom={i}
                        variants={navItemVariants}
                        initial="closed"
                        animate="open"
                      >
                        <Link
                          href={item.path}
                          onClick={() => handleNavClick(item.path)}
                          className={`flex items-center gap-4 py-4 px-4 rounded-xl transition-all duration-300 mb-2 ${
                            activeItem === item.path
                              ? "bg-gradient-to-r from-primary/10 to-primary/5 dark:from-primary/20 dark:to-primary/10 text-primary border-l-4 border-primary"
                              : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                          }`}
                        >
                          <Icon className={`w-6 h-6 ${activeItem === item.path ? "text-primary" : ""}`} />
                          <span className="text-base font-medium flex-1">{item.name}</span>
                          {activeItem === item.path && (
                            <motion.div
                              layoutId="activeMobile"
                              className="w-2 h-2 bg-primary rounded-full"
                              transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            />
                          )}
                        </Link>
                      </motion.div>
                    );
                  })}

                  {/* Social Links in Mobile */}
                  <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-800">
                    <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4 px-4">
                      Connect With Me
                    </h3>
                    <div className="flex gap-3 px-4">
                      {socialLinks.map((social, index) => (
                        <motion.a
                          key={social.label}
                          href={social.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-3 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-primary hover:bg-primary/10 dark:hover:bg-primary/20 rounded-xl transition-all"
                          whileHover={{ scale: 1.05, y: -2 }}
                          whileTap={{ scale: 0.95 }}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <social.icon className="w-5 h-5" />
                        </motion.a>
                      ))}
                    </div>
                  </div>
                </nav>

                {/* Footer */}
                <div className="p-6 border-t border-gray-200 dark:border-gray-800 space-y-4">
                  {/* Email */}
                  <a
                    href="mailto:mnishithareddy8765@gmail.com"
                    className="flex items-center gap-3 p-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-800/50 rounded-xl hover:from-primary/5 hover:to-primary/10 dark:hover:from-primary/10 dark:hover:to-primary/5 transition-all group"
                  >
                    <div className="p-2 bg-white dark:bg-gray-700 rounded-lg shadow-sm group-hover:shadow-md transition-shadow">
                      <FiMail className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500 dark:text-gray-400">Email Me</p>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-primary transition-colors truncate">
                        mnishithareddy8765@gmail.com
                      </p>
                    </div>
                    <FiArrowRight className="w-4 h-4 text-gray-400 group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </a>

                  {/* Theme Toggle */}
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-800/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white dark:bg-gray-700 rounded-lg shadow-sm">
                        {!isDarkMode ? (
                          <FiSun className="w-5 h-5 text-yellow-500" />
                        ) : (
                          <FiMoon className="w-5 h-5 text-primary" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Theme</p>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {isDarkMode ? "Dark Mode" : "Light Mode"}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={toggleTheme}
                      className="relative w-12 h-6 bg-gray-300 dark:bg-gray-600 rounded-full p-1 transition-colors"
                    >
                      <motion.span
                        animate={{ x: isDarkMode ? 24 : 0 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-md"
                      />
                    </button>
                  </div>

                  {/* Hire Me Button */}
                  <Link
                    href="/Contact"
                    onClick={() => setMobileMenuOpen(false)}
                    className="group block w-full py-3.5 bg-gradient-to-r from-primary to-primary/90 text-white font-semibold rounded-xl text-center shadow-lg hover:shadow-xl transition-all hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <span className="flex items-center justify-center gap-2">
                      Hire Me!
                      <FiArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </Link>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}