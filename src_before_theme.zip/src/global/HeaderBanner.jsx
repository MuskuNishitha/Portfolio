import React from "react";
import Link from "next/link";

const HeaderBanner = ({ title }) => {
  return (
    <section className="relative bg-[url('/assets/breadcrumb-bg.jpg')] bg-cover bg-center py-40 overflow-hidden">
      <div className="absolute inset-0 bg-black/10"></div>

      <div className="container-custom relative z-10">
        <div className="text-center">
          <h1 className="text-7xl md:text-8xl font-bold text-white mb-4 select-none">
            {title}
          </h1>

          <div className="flex items-center justify-center gap-3 text-lg">
            <Link href="/" className="text-gray-400 hover:text-white">
              Home
            </Link>
            <span className="text-[#fff]">→</span>
            <span className="text-white font-medium">{title}</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeaderBanner;